function s = EmptyFeatureStruct
% Dummy function for the feature struct.
%
% Copyright (C) Daphne Koller, Stanford Univerity, 2012

s = struct('var', [], 'assignment', [], 'paramIdx', []);

end

